package def;
import robocode.*;
import java.awt.*;

// API help : https://robocode.sourceforge.io/docs/robocode/robocode/Robot.html

/**
 * AbRoboCode - a robot by Ghazi Abbas
 * 
 */
public class AbRoboCode extends TeamRobot
{
	boolean moveDir;
	/**
	 * run: AbRoboCode's default behavior
	 */
	public void run() {
		// Initialization of the robot should be put here

		//keep track of moving direction so u can use it when u hit a wall
		
		// setColors, from my teammate // body,gun,radar
		setColors(new Color(0.5f,0f,0f),new Color(0.5f,0.5f,0.5f),new Color(0.5f,0.5f,0.5f),new Color(0.5f,0f,0f),new Color(0.5f,0f,0f));
		// Robot main loop
		while(true) 
		{
			// run around!
			ahead(100);
			moveDir = true;
			turnGunRight(360);
		}
	}

	/**
	 * onScannedRobot: What to do when you see another robot
	 */
	public void onScannedRobot(ScannedRobotEvent x) {
		//check if scanned is a teammate, if it isnt shoot
		if (isTeammate(x.getName()))
		{
			setTurnRight(90);
			ahead(70);
		}
		else 
		{
			fire(3);
		}
		scan();
	}

	/**
	 * onHitByBullet: What to do when you're hit by a bullet
	 */
	public void onHitByBullet(HitByBulletEvent e) {
		// Replace the next line with any behavior you would like
		back(10);
	}
	
	/**
	 * onHitWall: What to do when you hit a wall
	 */
	public void onHitWall(HitWallEvent e) {
		// Replace the next line with any behavior you would like
		if(moveDir ==true )
		{
			back(400);

		} else 
		{

			ahead(400);
		}


	}	


	public void onHitRobot(HitRobotEvent x)
	{	//check where the robot is
		if(x.getBearing() > -90 && x.getBearing() < 92)
		{
			back(200);
			moveDir = false;
			scan();

		}
		else
		{

			ahead(100);
			turnGunLeft(360);
		}


	}
}
